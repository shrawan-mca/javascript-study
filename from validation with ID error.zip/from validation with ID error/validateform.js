
function validateform()
		{

var fname = document.forms["myform"]["fname"].value;

if (fname==="") {

	alert("First Name must be filled out");
	
}



var lname = document.forms["myform"]["lname"].value; 


if (lname=="") {

	alert("Second Name must be filled out");
	return false;

}




var email = document.forms["myform"]["email"].value;

if (email=="") {

	document.getElementById('error').innerHTML = "Plase Enter your Enter Address!!";
	return false;
}


var UN = document.forms["myform"]["UN"].value;

if (UN=="") {

	alert("User Name must be filled out");
	return false;

}


var password = document.forms["myform"]["password"].value;

if (password=="") {

	alert("password must be filled out");
	return false;

}

var dob = document.forms["myform"]["dob"].value;

if (dob=="") {

	alert("Enter your date of birth");
}

var gender = document.forms["myform"]["gender"].value;

ErrorText= "";
if ( ( myform.gender[0].checked == false ) && ( myform.gender[1].checked == false ) )
{
alert ( "Please choose your Gender: Male or Female" );
return false;
}
if (ErrorText= "") { myform.submit() }


var check = document.forms["myform"]["check"].checked;

if(check==false){

	alert("Plase check your checkbox");
}

}